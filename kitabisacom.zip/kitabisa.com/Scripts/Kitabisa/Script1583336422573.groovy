import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser(GlobalVariable.Kitabisa, FailureHandling.CONTINUE_ON_FAILURE)

WebUI.scrollToElement(findTestObject('bantusiapa'), 0)

WebUI.click(findTestObject('campaignGroup'))

//WebUI.click(findTestObject('campaignText2'))
WebUI.click(findTestObject('button_DONASI SEKARANG'))

WebUI.click(findTestObject('Nominal10000'))

WebUI.delay(2)

String a = findTestObject('textTransferBCA')

b = WebUI.getText(findTestObject('textTransferBCA'))

WebUI.scrollToElement(findTestObject('textTransferBCA'), 0)

//WebUI.verifyElementText(findTestObject('textTransferBCA'), a)
WebUI.click(findTestObject('textTransferBCA'))

WebUI.delay(2)

WebUI.setText(findTestObject('field_nama'), 'Bedha Jahsha')

WebUI.setText(findTestObject('field_email_nohp'), 'bedha@mailinator.com')

WebUI.click(findTestObject('button_LANJUTKAN PEMBAYARAN'))

WebUI.delay(5)

WebUI.scrollToElement(findTestObject('buttonx3'), 0)

WebUI.delay(3)

WebUI.click(findTestObject('buttonx3'))

WebUI.click(findTestObject('back_button'))

